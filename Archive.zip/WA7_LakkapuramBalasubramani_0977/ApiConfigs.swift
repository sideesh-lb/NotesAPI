//
//  ApiConfigs.swift
//  WA7_LakkapuramBalasubramani_0977
//
//  Created by Sideeshwaran Balasubramani on 11/2/23.
//

import Foundation

class APIConfigs{
    //MARK: API base URL...
    static let baseURL = "http://apis.sakibnm.space:3000/api/auth/"
    
    static let baseNotesURL = "http://apis.sakibnm.space:3000/api/note/"
}
